using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;
using NUnit.Framework;
using Npgsql;
using System.Net.Http;
using System.Text.Json;
using EcommerceTests.Helpers;
using EcommerceTests.PageObjects;

namespace EcommerceTests.Integration
{
    [TestFixture]
    public class PromotionFlowTests : PageTest
    {
        private ApiClient _apiClient;
        private DatabaseHelper _dbHelper;
        private string _testPromotionId;

        [SetUp]
        public void Setup()
        {
        }

        [TearDown]
        public async Task Cleanup()
        {
        }

        [Test]
        public async Task TestFullPromotionFlowHappyPath()
        {
            Assert.Fail("TODO: Implement test");
        }

        [Test]
        public async Task TestInvalidPromoCode()
        {
            Assert.Fail("TODO: Implement test");
        }

        [Test]
        public async Task TestExpiredPromoCode()
        {
            Assert.Fail("TODO: Implement test");
        }

        [Test]
        public async Task TestWrongCategoryPromo()
        {
            Assert.Fail("TODO: Implement test");
        }
    }
}
