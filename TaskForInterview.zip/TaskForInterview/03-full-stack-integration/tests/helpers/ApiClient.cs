using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace EcommerceTests.Helpers
{
    public class ApiClient
    {
        private readonly HttpClient _httpClient;

        public ApiClient(string baseUrl, string apiKey = null)
        {
            throw new NotImplementedException();
        }

        public async Task<PromotionResponse> CreatePromotionAsync(object promotionData)
        {
            throw new NotImplementedException();
        }

        public async Task<PromotionResponse> GetPromotionAsync(string promotionId)
        {
            throw new NotImplementedException();
        }

        public async Task DeletePromotionAsync(string promotionId)
        {
            throw new NotImplementedException();
        }
    }

    public class PromotionResponse
    {
        public string PromotionId { get; set; }
        public string Code { get; set; }
        public string DiscountType { get; set; }
        public int DiscountValue { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
