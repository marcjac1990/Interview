using Npgsql;
using System.Data;

namespace EcommerceTests.Helpers
{
    public class DatabaseHelper
    {
        private NpgsqlConnection _connection;

        public DatabaseHelper(string host, int port, string database, string username, string password)
        {
            throw new NotImplementedException();
        }

        public void Connect()
        {
            throw new NotImplementedException();
        }

        public void Disconnect()
        {
            throw new NotImplementedException();
        }

        public Order GetOrderById(string orderId)
        {
            throw new NotImplementedException();
        }

        public AuditLog GetAuditLogByOrderId(string orderId)
        {
            throw new NotImplementedException();
        }

        public void DeleteOrder(string orderId)
        {
            throw new NotImplementedException();
        }

        public bool VerifyOrderTotals(string orderId, decimal expectedOriginal,
            decimal expectedDiscount, decimal expectedFinal)
        {
            throw new NotImplementedException();
        }
    }

    public class Order
    {
        public string OrderId { get; set; }
        public string CustomerEmail { get; set; }
        public decimal OriginalAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal FinalAmount { get; set; }
        public string PromotionCode { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class AuditLog
    {
        public int AuditId { get; set; }
        public string PromotionId { get; set; }
        public string OrderId { get; set; }
        public decimal DiscountApplied { get; set; }
        public DateTime UsedAt { get; set; }
    }
}
