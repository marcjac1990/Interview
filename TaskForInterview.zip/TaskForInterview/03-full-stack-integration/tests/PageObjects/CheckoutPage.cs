using Microsoft.Playwright;

namespace EcommerceTests.PageObjects
{
    public class CheckoutPage
    {
        private readonly IPage _page;

        private ILocator PromoCodeInput => _page.Locator("#promo-code");
        private ILocator ApplyPromoButton => _page.Locator("#apply-promo");
        private ILocator OriginalPrice => _page.Locator(".original-price");
        private ILocator DiscountAmount => _page.Locator(".discount-amount");
        private ILocator FinalPrice => _page.Locator(".final-price");
        private ILocator PlaceOrderButton => _page.Locator("#place-order");
        private ILocator OrderNumber => _page.Locator(".order-number");
        private ILocator SuccessMessage => _page.Locator(".success-message");
        private ILocator ErrorMessage => _page.Locator(".error-message");

        public CheckoutPage(IPage page)
        {
            _page = page;
        }

        public async Task NavigateAsync()
        {
            throw new NotImplementedException();
        }

        public async Task ApplyPromoCodeAsync(string code)
        {
            throw new NotImplementedException();
        }

        public async Task<decimal> GetOriginalPriceAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<decimal> GetDiscountAmountAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<decimal> GetFinalPriceAsync()
        {
            throw new NotImplementedException();
        }

        public async Task VerifyDiscountApplied(decimal expectedDiscount)
        {
            throw new NotImplementedException();
        }

        public async Task<string> PlaceOrderAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<bool> IsErrorDisplayedAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<string> GetErrorMessageAsync()
        {
            throw new NotImplementedException();
        }
    }
}
